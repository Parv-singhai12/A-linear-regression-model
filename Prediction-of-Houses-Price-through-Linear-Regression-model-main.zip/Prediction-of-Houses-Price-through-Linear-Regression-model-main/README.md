# Prodigy-ML-01
Implementation a linear regression model to predict the prices of houses based on their square footage and the number of bedrooms and bathrooms.
